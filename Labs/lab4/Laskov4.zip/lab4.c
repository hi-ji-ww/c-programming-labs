#include <stdio.h>

#define MAX_ROWS 100
#define MAX_COLS 100

void inputAndDisplayArray(int array[MAX_ROWS][MAX_COLS], int rows, int cols) {
    int i, j;
    printf("Enter array elements row by row:\n");
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            scanf("%d", &array[i][j]);
        }
    }

    printf("Source array:\n");
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            printf("%d ", array[i][j]);
        }
        printf("\n");
    }
}

void formNewArray(int rows, int cols, int array[MAX_ROWS][MAX_COLS], int specifiedIndex, int newArray[MAX_ROWS][MAX_COLS], int *newRows) {
    int i, j;
    *newRows = 0;
    for (i = 0; i < rows; i++) {
        if (array[i][0] % 2 != 0 && array[i][specifiedIndex] % 2 != 0) {
            for (j = 0; j < cols; j++) {
                newArray[*newRows][j] = array[i][j];
            }
            (*newRows)++;
        }
    }
}

int main() {
    int rows, cols, specifiedIndex;
    int array[MAX_ROWS][MAX_COLS];
    int newArray[MAX_ROWS][MAX_COLS];
    int newRows, i, j;

    printf("Enter the number of lines: ");
    scanf("%d", &rows);
    printf("Enter the number of columns: ");
    scanf("%d", &cols);

    if (rows > MAX_ROWS || cols > MAX_COLS) {
        printf("Error: Maximum array size exceeded.\n");
        return 1;
    }

    inputAndDisplayArray(array, rows, cols);

    printf("Enter the item number to check (0 - indexing): ");
    scanf("%d", &specifiedIndex);

    formNewArray(rows, cols, array, specifiedIndex, newArray, &newRows);

    printf("Result array:\n");
    for (i = 0; i < newRows; i++) {
        for (j = 0; j < cols; j++) {
            printf("%d ", newArray[i][j]);
        }
        printf("\n");
    }

    return 0;
}
