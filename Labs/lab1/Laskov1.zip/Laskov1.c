#include <stdio.h>

int main() {
    int number;
    int proizved = 1;
    int suma = 0;
    int fl = 1;

    printf("Enter a sequence of numbers (to complete, enter a number less than the sum):\\n");

    while (fl == 1) {
        scanf("%d", &number);

        if (number < suma) {
            fl = 0;
        }

        if (number > 0) {
            proizved *= number;
        }

        suma += number;
    }

    printf("The product of positive numbers: %d\\n", proizved);
    return 0;
}
