#include <stdio.h>

int main() {
    int arr[100];
    int count = 0; 
    int first_sign; 
    int opposite_sign_flag = 0, num, temp, new_count, i, j; 


    while (count < 100 && opposite_sign_flag == 0) {
        printf("Enter the number: ");
        scanf("%d", &num);

        if (count == 0) {
            first_sign = num > 0 ? 1 : -1;
        } else if (num * first_sign < 0) {
            opposite_sign_flag = 1; 
            continue;
        }

        arr[count] = num;
        count++;
    }

    for (i = 0; i < count / 2; i++) {
        temp = arr[i];
        arr[i] = arr[count - i - 1];
        arr[count - i - 1] = temp;
    }

    new_count = count;
    for (i = count / 2; i < count; i++) {
        if (arr[i] % 2 == 0) {
            new_count--;
            for (j = i; j < count - 1; j++) {
                arr[j] = arr[j + 1];
            }
            i--;
        }
    }

    printf("Transformed array: ");
    for (i = 0; i < new_count; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}