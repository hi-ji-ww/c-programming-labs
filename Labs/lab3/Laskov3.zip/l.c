#include <stdio.h>

#define ROWS 3
#define COLS 4

int main() {
    int array[ROWS][COLS] = {
        {1, -2, 3, -4},
        {-5, 6, -7, 8},
        {9, -10, 11, -12}
    };

    int signChanges = 0, i, j;
    i = 0;
    j = 0;

    for (i = 0; i < ROWS; i++) {
        for (j = 0; j < COLS; j++) {
            if (j > 0 && (array[i][j] > 0 && array[i][j-1] < 0 || array[i][j] < 0 && array[i][j-1] > 0)) {
                signChanges++;
            }
            if (i > 0 && (array[i][j] > 0 && array[i-1][j] < 0 || array[i][j] < 0 && array[i-1][j] > 0)) {
                signChanges++;
            }
        }
    }

    printf("Number of sign changes: %d", signChanges);
    return 0;
}
