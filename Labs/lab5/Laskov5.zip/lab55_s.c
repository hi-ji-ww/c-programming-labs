#include <stdio.h>
#include <string.h>

#define MAX_TEXT 1000
#define MAX_DELIMIT 100

void split_str(const char *text, const char *delimiters, int *indices, int *count) {
    int length = strlen(text), i;
    *count = 0;

    for (i = 0; i < length; i++) {
        if (strchr(delimiters, text[i]) != NULL) {
            indices[(*count)++] = i;
        }
    }
    indices[*count] = length;
}

void count_delimiters(const char *text, const char *delimiters) {
    int counts[MAX_DELIMIT] = {0};
    int i, j;
    char delimiter;
    for (i = 0; delimiters[i] != '\0'; i++) {
        delimiter = delimiters[i];
        for (j = 0; text[j] != '\0'; j++) {
            if (text[j] == delimiter) {
                counts[i]++;
            }
        }
    }

    printf("Counts of delimiters:\n");
    for (i = 0; delimiters[i] != '\0'; i++) {
        printf("'%c': %d\n", delimiters[i], counts[i]);
    }
}

int main() {
    char delimiters[MAX_DELIMIT], text[MAX_TEXT];
    int indices[MAX_TEXT];
    int count, i, start, end;

    printf("Enter a string: ");
    fgets(text, MAX_TEXT, stdin);
    text[strcspn(text, "\n")] = 0;

    printf("Enter delimiter characters: ");
    fgets(delimiters, MAX_DELIMIT, stdin);
    delimiters[strcspn(delimiters, "\n")] = 0;

    split_str(text, delimiters, indices, &count);

    count_delimiters(text, delimiters);

    return 0;
}
